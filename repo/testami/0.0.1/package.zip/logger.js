exports.run = function(){
	alert("I am a logger");
};
