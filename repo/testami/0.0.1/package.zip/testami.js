exports.run = function(){
	var logger = require("./logger");
    logger.run();
}
