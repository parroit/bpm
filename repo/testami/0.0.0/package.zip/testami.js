exports.run = function(){
	var testModule = require("test");
    var bazModule = require("baz");
    testModule.doLog(); 
    bazModule.doLog(); 
}
