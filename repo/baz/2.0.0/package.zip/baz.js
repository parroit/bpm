exports.doLog = function(){
	var foo = require("foo");
	foo.log("ciao");	
}
