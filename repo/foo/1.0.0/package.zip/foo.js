exports.log = function(msg) {
	alert(msg + " -> foo 1.0.0");
};