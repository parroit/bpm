exports.log = function(msg) {
	alert(msg + " -> foo 2.0.0");
};