module.exports = function gogogo() {
    var a = require("./a");
    var b = require("./b");
    return a + b;
};